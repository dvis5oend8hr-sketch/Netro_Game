# Netro Game - UI Tools Scaffold

Project: **『Nєтro』𒆜GAME𒆜**

This is a minimal Flutter scaffold prepared for building an Android APK via GitHub Actions.

## What is included
- Splash image (assets/splash.png) with the app name and subtle TikTok username '@gg2pj5'.
- Basic UI:
  - Home page
  - Tools page (DPI, brightness, volume sliders) — all simulated UI-only.
  - Shizuku connection mock (UI only).
- GitHub Actions workflow `.github/workflows/build_apk.yml` to build APK automatically.

## How to use
1. Create a new repository on GitHub (or use an existing one).
2. Upload all files from this repo (or upload this ZIP).
3. On GitHub, go to **Actions** → select the `Build Flutter Android APK` workflow → **Run workflow**.
4. After the workflow finishes, download the artifact `app-release-apk` from the run page.

## Notes
- This project **does not** perform real DPI changes or interact with Shizuku. It's a UI scaffold; you will need to integrate Shizuku or ADB commands locally or add appropriate Android code for actual system changes.
- If you'd like, I can later guide you how to:
  - Add Shizuku integration.
  - Add a signed keystore for Play Store release.