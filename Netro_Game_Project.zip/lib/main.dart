import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const NetroApp());
}

class NetroApp extends StatelessWidget {
  const NetroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "『Nєтro』𒆜GAME𒆜",
      theme: ThemeData.dark().copyWith(
        useMaterial3: true,
        textTheme: GoogleFonts.robotoTextTheme(ThemeData.dark().textTheme),
        colorScheme: ColorScheme.dark(primary: Color(0xFFD4AF37)),
      ),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 900), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomePage()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          color: Color(0xFF08080A),
        ),
        child: Center(
          child: Image.asset('assets/splash.png', width: 900, fit: BoxFit.contain),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("『Nєtro』𒆜GAME𒆜"),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.info_outline),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: ListView(
          children: [
            const SizedBox(height: 8),
            const Card(
              child: ListTile(
                leading: Icon(Icons.memory),
                title: Text("Device Info"),
                subtitle: Text("View device specifications"),
              ),
            ),
            const SizedBox(height: 8),
            const Card(
              child: ListTile(
                leading: Icon(Icons.aspect_ratio),
                title: Text("DPI Controller"),
                subtitle: Text("Change screen DPI (requires Shizuku/ADB)"),
              ),
            ),
            const SizedBox(height: 8),
            const Card(
              child: ListTile(
                leading: Icon(Icons.crop_free),
                title: Text("Icon / UI Scaling"),
                subtitle: Text("Scale icons and UI elements"),
              ),
            ),
            const SizedBox(height: 8),
            const Card(
              child: ListTile(
                leading: Icon(Icons.brightness_medium),
                title: Text("Brightness Control"),
                subtitle: Text("Adjust screen brightness"),
              ),
            ),
            const SizedBox(height: 8),
            const Card(
              child: ListTile(
                leading: Icon(Icons.volume_up),
                title: Text("Sound Control"),
                subtitle: Text("Adjust volume levels"),
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ToolsPage()));
              },
              icon: const Icon(Icons.build),
              label: const Text("Open Tools"),
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
                backgroundColor: const Color(0xFFD4AF37),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ToolsPage extends StatefulWidget {
  const ToolsPage({super.key});
  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  final TextEditingController dpiController = TextEditingController(text: "420");
  double scale = 1.0;

  void applyDpi() {
    final dpi = dpiController.text;
    // Placeholder: show dialog. Real Shizuku/ADB integration must be added manually.
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text("Apply DPI (Simulated)"),
      content: Text("Requested DPI: \$dpi\n\nThis is a UI-only simulation. To apply DPI changes you need to integrate Shizuku or use ADB."),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tools - DPI & System"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            TextField(
              controller: dpiController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Target DPI",
                hintText: "e.g. 420",
                prefixIcon: Icon(Icons.aspect_ratio),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: applyDpi,
              child: const Text("Apply DPI (Simulated)"),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD4AF37), foregroundColor: Colors.black),
            ),
            const SizedBox(height: 18),
            const Divider(),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.phone_iphone),
              title: const Text("Brightness"),
              subtitle: const Text("UI slider only (simulated)"),
            ),
            Slider(value: scale, onChanged: (v){ setState((){ scale = v; }); }, min: 0.5, max: 1.8),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.volume_up),
              title: const Text("Volume"),
              subtitle: const Text("UI slider only (simulated)"),
            ),
            const SizedBox(height: 6),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                // placeholder: Shizuku connect
                showDialog(context: context, builder: (_) => AlertDialog(
                  title: const Text("Shizuku (Simulated)"),
                  content: const Text("This is a UI mock of Shizuku connection. Real integration must be added manually."),
                  actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))],
                ));
              },
              icon: const Icon(Icons.link),
              label: const Text("Connect to Shizuku"),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD4AF37), foregroundColor: Colors.black),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}